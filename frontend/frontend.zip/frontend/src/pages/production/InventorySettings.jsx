import { useEffect, useState } from "react";
import { Settings, Plus, Edit, Trash2, BriefcaseBusiness, Languages, CornerDownRight, FolderPlus, ChevronRight, ChevronDown, GripVertical, ChevronsDownUp, ChevronsUpDown } from "lucide-react";

import { useI18n } from "../../hooks/useI18n";

import CustomSelect from "../../components/useful/CustomSelect";
import Breadcrumbs from "../../components/useful/Breadcrumbs";
import ActionModal from "../../components/useful/ActionModal";
import IconPicker from "../../components/useful/IconPicker";
import TranslatedText from "../../components/useful/TranslatedText";
import TranslationEditorModal from "../../components/useful/TranslationEditorModal";

import {
  getInventoryCategories,
  createInventoryCategory,
  updateInventoryCategory,
  deleteInventoryCategory,
} from "../../services/inventoryCategoryService";
import { getCompanies } from "../../services/companyService";
import { getInventoryIcon } from "../../utils/inventoryIcons";

import styles from "./InventorySettings.module.css";

export default function InventorySettings() {
  const { t } = useI18n();

  const [companies, setCompanies] = useState([]);
  const [selectedCompanyId, setSelectedCompanyId] = useState("");
  const [companiesLoading, setCompaniesLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        setCompaniesLoading(true);
        const data = await getCompanies();
        const list = Array.isArray(data) ? data : [];
        setCompanies(list);
        if (!selectedCompanyId && list.length > 0) setSelectedCompanyId(list[0]._id);
      } catch (error) {
        console.error("Failed to load companies:", error);
      } finally {
        setCompaniesLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const companyOptions = companies.map((c) => ({
    value: c._id,
    label: c.name || c.tradeName || t("employees.company.unnamed"),
  }));

  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  const reload = async () => {
    if (!selectedCompanyId) return;
    const data = await getInventoryCategories(selectedCompanyId);
    setCategories(data);
  };

  useEffect(() => {
    if (!selectedCompanyId) { setCategories([]); setLoading(false); return; }
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const data = await getInventoryCategories(selectedCompanyId);
        if (!cancelled) setCategories(data);
      } catch (error) {
        console.error("Failed to load categories:", error);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [selectedCompanyId]);

  const [showForm, setShowForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [formName, setFormName] = useState("");
  const [formIcon, setFormIcon] = useState("Package");
  const [formDescription, setFormDescription] = useState("");
  // accounting: purchase account of this category + fixed-asset flag
  const [formAccount, setFormAccount] = useState("");
  const [formFixedAsset, setFormFixedAsset] = useState(false);
  // Sub-categories: "Profilés aluminium" › "Série ATLAS 78 — coulissants"…
  const [formParent, setFormParent] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  const openCreateForm = (parent = null) => {
    setEditingCategory(null);
    setFormParent(parent?._id || "");
    setFormName("");
    setFormIcon(parent?.icon || "Package");
    setFormDescription("");
    setFormAccount(""); // empty = inherits the parent's account
    setFormFixedAsset(false);
    setFormError("");
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const openEditForm = (category) => {
    setEditingCategory(category);
    setFormName(category.name);
    setFormIcon(category.icon || "Package");
    setFormDescription(category.description || "");
    setFormAccount(category.accountingAccount || "");
    setFormFixedAsset(!!category.isFixedAsset);
    setFormParent(category.parent || "");
    setFormError("");
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingCategory(null);
  };

  // ---------- Translations editor (name, description) ----------
  const [translatingCategory, setTranslatingCategory] = useState(null);

  const handleTranslationSaved = (field, bucket) => {
    setCategories((prev) =>
      prev.map((c) =>
        c._id === translatingCategory?._id
          ? { ...c, translations: { ...c.translations, [field]: bucket } }
          : c
      )
    );
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!formName.trim()) {
      setFormError(t("inventorySettings.errors.nameRequired"));
      return;
    }

    setSaving(true);
    setFormError("");
    try {
      if (editingCategory) {
        await updateInventoryCategory(editingCategory._id, {
          name: formName, icon: formIcon, description: formDescription, accountingAccount: formAccount.trim(), isFixedAsset: formFixedAsset, parent: formParent || null,
        });
      } else {
        await createInventoryCategory({
          company: selectedCompanyId, name: formName, icon: formIcon, description: formDescription, accountingAccount: formAccount.trim(), isFixedAsset: formFixedAsset, parent: formParent || null,
        });
      }
      closeForm();
      await reload();
    } catch (error) {
      setFormError(error.response?.data?.message || t("inventorySettings.errors.saveFailed"));
    } finally {
      setSaving(false);
    }
  };

  const [modal, setModal] = useState({ open: false, type: "confirm", title: "", message: "" });
  const [pendingDeleteId, setPendingDeleteId] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);

  const askDelete = (category) => {
    setPendingDeleteId(category._id);
    setModal({ open: true, type: "confirm", title: t("inventorySettings.deleteTitle"), message: t("inventorySettings.deleteSureMessage") });
  };

  const closeModal = () => {
    if (actionLoading) return;
    setModal((prev) => ({ ...prev, open: false }));
  };

  const handleConfirmDelete = async () => {
    setActionLoading(true);
    try {
      await deleteInventoryCategory(pendingDeleteId);
      await reload();
      setModal((prev) => ({ ...prev, open: false }));
    } catch (error) {
      setModal({ open: true, type: "error", title: t("common.fail"), message: error.response?.data?.message || t("inventorySettings.errors.deleteFailed") });
    } finally {
      setActionLoading(false);
    }
  };

  // ---------- Tree: collapsible sub-categories + drag & drop to re-parent ----------
  const [expanded, setExpanded] = useState(() => new Set());
  const [dragId, setDragId] = useState(null);
  const [dropTarget, setDropTarget] = useState(null);
  const toggle = (id) => setExpanded((prev) => { const n = new Set(prev); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  // Articles of a category including its sub-categories.
  const total = (cat) => categories.filter((c) => c._id === cat._id || (c.path || []).includes(cat._id)).reduce((a, c) => a + (c.productCount || 0), 0);
  // Descendants of `rootId` whose every ancestor below the root is expanded (tree order is kept).
  const visibleChildren = (rootId) => categories.filter((c) => {
    const path = c.path || [];
    const i = path.indexOf(rootId);
    if (i < 0) return false;
    return path.slice(i + 1).every((id) => expanded.has(id));
  });
  // Height of a category's own sub-tree (0 = no children) — max depth is 4 levels (0..3).
  const subtreeHeight = (cat) => Math.max(0, ...categories.filter((c) => (c.path || []).includes(cat._id)).map((c) => (c.depth || 0) - (cat.depth || 0)));
  const canDropOn = (target) => {
    const dragged = categories.find((c) => c._id === dragId);
    if (!dragged || !target || dragged._id === target._id) return false;
    if ((target.path || []).includes(dragged._id)) return false; // into its own branch
    if (String(dragged.parent || "") === String(target._id)) return false; // already there
    return (target.depth || 0) + 1 + subtreeHeight(dragged) <= 3;
  };
  const moveTo = async (parentId) => {
    const id = dragId;
    setDragId(null);
    setDropTarget(null);
    if (!id) return;
    try {
      await updateInventoryCategory(id, { parent: parentId });
      if (parentId) setExpanded((prev) => new Set(prev).add(parentId));
      await reload();
    } catch (error) {
      setModal({ open: true, type: "error", title: t("common.fail"), message: error.response?.data?.message || t("inventorySettings.errors.saveFailed") });
    }
  };
  const dragProps = (cat) => ({
    draggable: true,
    onDragStart: (e) => { e.stopPropagation(); setDragId(cat._id); e.dataTransfer.effectAllowed = "move"; try { e.dataTransfer.setData("text/plain", cat._id); } catch { /* old browsers */ } },
    onDragEnd: () => { setDragId(null); setDropTarget(null); },
    onDragOver: (e) => { if (!canDropOn(cat)) return; e.preventDefault(); e.stopPropagation(); if (dropTarget !== cat._id) setDropTarget(cat._id); },
    onDragLeave: (e) => { e.stopPropagation(); if (dropTarget === cat._id) setDropTarget(null); },
    onDrop: (e) => { if (!canDropOn(cat)) return; e.preventDefault(); e.stopPropagation(); moveTo(cat._id); },
  });
  const actions = (category) => (
    <div className={styles.categoryActions}>
      {(category.depth || 0) < 3 && (
        <button type="button" className="tableActionBtn" title={t("cv.addSubCategory")} onClick={() => openCreateForm(category)}>
          <FolderPlus size={14} />
        </button>
      )}
      <button type="button" className="tableActionBtn" title={t("contentTranslation.editButton")} onClick={() => setTranslatingCategory(category)}>
        <Languages size={14} />
      </button>
      <button type="button" className="tableActionBtn" title={t("common.edit")} onClick={() => openEditForm(category)}>
        <Edit size={14} />
      </button>
      <button type="button" className="tableActionBtn tableActionBtnDanger" title={t("common.delete")} onClick={() => askDelete(category)}>
        <Trash2 size={14} />
      </button>
    </div>
  );

  return (
    <div className="pageShell">
      <Breadcrumbs items={[{ label: t("sidebar.technical"), href: "/technical/catalog" }, { label: t("inventorySettings.title") }]} />

      <div className="pageHeader">
        <div>
          <div className="pageTitleRow">
            <Settings size={20} />
            <h1>{t("inventorySettings.title")}</h1>
          </div>
          <p className="pageSubtitle">{t("inventorySettings.subtitle")}</p>
        </div>
        {selectedCompanyId && (
          <div className="pageHeaderActions">
            <button type="button" className="btnPrimary" onClick={() => openCreateForm()}>
              <Plus size={16} />
              {t("inventorySettings.addCategory")}
            </button>
          </div>
        )}
      </div>

      <div className={styles.toolbar}>
        <div className="filterGroup">
          <label>{t("employees.toolbar.company")}</label>
          <CustomSelect value={selectedCompanyId} onSelect={setSelectedCompanyId} options={companyOptions}
            placeholder={companiesLoading ? t("employees.toolbar.loadingCompanies") : t("employees.toolbar.selectCompany")}
            disabled={companiesLoading} />
        </div>
      </div>

      {showForm && selectedCompanyId && (
        <form className={styles.formCard} onSubmit={handleSubmit}>
          <h3>{editingCategory ? t("inventorySettings.editCategory") : t("inventorySettings.addCategory")}</h3>
          {formError && <div className={styles.errorMessage}>{formError}</div>}

          <div className={styles.formGrid}>
            <div className={styles.formField}>
              <label>{t("inventorySettings.fields.name")}</label>
              <input type="text" className={styles.textInput} value={formName} onChange={(e) => setFormName(e.target.value)} placeholder={t("inventorySettings.fields.namePlaceholder")} />
            </div>
            <div className={styles.formField}>
              <label>{t("cv.parentCategory")}</label>
              <CustomSelect value={formParent} onSelect={setFormParent}
                options={[{ value: "", label: t("cv.noParent") }, ...categories
                  // not itself nor one of its own sub-categories
                  .filter((c) => !editingCategory || (c._id !== editingCategory._id && !(c.path || []).includes(editingCategory._id)))
                  .filter((c) => (c.depth || 0) < 3)
                  .map((c) => ({ value: c._id, label: c.fullName || c.name }))]} />
              <small className={styles.fieldHint}>{t("cv.parentHint")}</small>
            </div>
            <div className={styles.formField}>
              <label>{t("inventorySettings.fields.icon")}</label>
              <IconPicker value={formIcon} onSelect={setFormIcon} />
            </div>
            <div className={styles.formField} style={{ gridColumn: "1 / -1" }}>
              <label>{t("inventorySettings.fields.description")}</label>
              <input type="text" className={styles.textInput} value={formDescription} onChange={(e) => setFormDescription(e.target.value)} placeholder={t("inventorySettings.fields.descriptionPlaceholder")} />
            </div>
            {/* Where purchases of this category go in the accounting export */}
            <div className={styles.formField}>
              <label>{t("inventorySettings.fields.accountingAccount")}</label>
              <input type="text" inputMode="numeric" className={styles.textInput} value={formAccount} placeholder="6121"
                onChange={(e) => setFormAccount(e.target.value.replace(/[^0-9]/g, "").slice(0, 10))} />
              <small className={styles.fieldHint}>{t("inventorySettings.fields.accountingAccountHint")}</small>
            </div>
            <div className={styles.formField}>
              <label>{t("inventorySettings.fields.fixedAsset")}</label>
              <label className={styles.inlineSwitch}>
                <input type="checkbox" className="switchToggle" checked={formFixedAsset} onChange={(e) => setFormFixedAsset(e.target.checked)} />
                <span>{formFixedAsset ? t("inventorySettings.fields.fixedAssetOn") : t("inventorySettings.fields.fixedAssetOff")}</span>
              </label>
            </div>
          </div>

          <div className={styles.formActions}>
            <button type="button" className="btnCancel" onClick={closeForm}>{t("common.cancel")}</button>
            <button type="submit" className="btnPrimary" disabled={saving}>
              {saving ? t("payroll.buttons.saving") : editingCategory ? t("common.update") : t("common.create")}
            </button>
          </div>
        </form>
      )}

      {!selectedCompanyId && !companiesLoading && (
        <div className="emptyStateBlock">
          <div className="emptyStateIcon"><BriefcaseBusiness size={28} /></div>
          <h2>{t("employees.emptyNoCompany.title")}</h2>
          <p>{t("employees.emptyNoCompany.message")}</p>
        </div>
      )}

      {selectedCompanyId && !loading && categories.length === 0 && (
        <div className="emptyStateBlock">
          <div className="emptyStateIcon"><Settings size={28} /></div>
          <h2>{t("inventorySettings.emptyTitle")}</h2>
          <p>{t("inventorySettings.emptyMessage")}</p>
        </div>
      )}

      {selectedCompanyId && categories.length > 0 && (
        <>
          <div className={styles.treeToolbar}>
            <span className={styles.fieldHint}>{t("cv.dragHint")}</span>
            <div className={styles.treeToolbarActions}>
              <button type="button" className="btnEdit" onClick={() => setExpanded(new Set(categories.filter((c) => c.childCount > 0).map((c) => c._id)))}><ChevronsUpDown size={14} /> {t("cv.expandAll")}</button>
              <button type="button" className="btnEdit" onClick={() => setExpanded(new Set())}><ChevronsDownUp size={14} /> {t("cv.collapseAll")}</button>
            </div>
          </div>
          {/* Drop here → back to the top level */}
          {dragId && (categories.find((c) => c._id === dragId)?.depth || 0) > 0 && (
            <div className={`${styles.rootDrop} ${dropTarget === "root" ? styles.dropActive : ""}`}
              onDragOver={(e) => { e.preventDefault(); setDropTarget("root"); }}
              onDragLeave={() => setDropTarget(null)}
              onDrop={(e) => { e.preventDefault(); moveTo(null); }}>
              {t("cv.dropToTop")}
            </div>
          )}
          <div className={styles.categoryGrid}>
            {categories.filter((c) => !c.depth).map((top) => {
              const Icon = getInventoryIcon(top.icon);
              const branch = categories.filter((c) => (c.path || []).includes(top._id));
              const open = expanded.has(top._id);
              return (
                <div key={top._id} className={`${styles.categoryGroup} ${dropTarget === top._id ? styles.dropActive : ""}`}>
                  <div className={styles.categoryCard} {...dragProps(top)}>
                    <GripVertical size={14} className={styles.grip} />
                    {top.childCount > 0 ? (
                      <button type="button" className={styles.toggle} aria-expanded={open} title={open ? t("cv.collapse") : t("cv.expand")} onClick={() => toggle(top._id)}>
                        {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                      </button>
                    ) : <span className={styles.togglePlaceholder} />}
                    <div className={styles.categoryIcon} style={{ color: top.color }}>
                      <Icon size={22} />
                    </div>
                    <div className={styles.categoryInfo} onClick={() => top.childCount > 0 && toggle(top._id)} style={{ cursor: top.childCount > 0 ? "pointer" : "default" }}>
                      <span className={styles.categoryName}>
                        <TranslatedText doc={top} field="name" />
                      </span>
                      <span className={styles.categoryDescription}>
                        {top.description ? <TranslatedText doc={top} field="description" /> : null}
                        {top.description ? " · " : ""}{t("cv.articlesCount").replace("{n}", total(top))}
                        {branch.length > 0 ? ` · ${t("cv.subCount").replace("{n}", branch.length)}` : ""}
                      </span>
                    </div>
                    {actions(top)}
                  </div>
                  {open && top.childCount > 0 && (
                    <div className={styles.subList}>
                      {visibleChildren(top._id).map((c) => {
                        const subOpen = expanded.has(c._id);
                        return (
                          <div key={c._id} className={`${styles.subRow} ${dropTarget === c._id ? styles.dropActive : ""}`} style={{ paddingInlineStart: 10 + (c.depth - 1) * 20 }} {...dragProps(c)}>
                            <GripVertical size={13} className={styles.grip} />
                            {c.childCount > 0 ? (
                              <button type="button" className={styles.toggle} aria-expanded={subOpen} onClick={() => toggle(c._id)}>
                                {subOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                              </button>
                            ) : <CornerDownRight size={13} className={styles.subArrow} />}
                            <div className={styles.categoryInfo} onClick={() => c.childCount > 0 && toggle(c._id)} style={{ cursor: c.childCount > 0 ? "pointer" : "default" }}>
                              <span className={styles.subName}><TranslatedText doc={c} field="name" /></span>
                              <span className={styles.categoryDescription}>
                                {c.description ? <><TranslatedText doc={c} field="description" /> · </> : null}
                                {t("cv.articlesCount").replace("{n}", total(c))}
                                {c.childCount > 0 ? ` · ${t("cv.subCount").replace("{n}", categories.filter((x) => (x.path || []).includes(c._id)).length)}` : ""}
                              </span>
                            </div>
                            {actions(c)}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}

      <ActionModal isOpen={modal.open} type={modal.type} title={modal.title} message={modal.message} loading={actionLoading}
        onConfirm={modal.type === "confirm" ? handleConfirmDelete : undefined} onClose={closeModal} />

      <TranslationEditorModal
        isOpen={!!translatingCategory}
        onClose={() => setTranslatingCategory(null)}
        resourceType="inventoryCategory"
        resourceId={translatingCategory?._id}
        fields={[
          { key: "name", label: t("inventorySettings.fields.name") },
          { key: "description", label: t("inventorySettings.fields.description") },
        ]}
        onSaved={handleTranslationSaved}
      />
    </div>
  );
}
