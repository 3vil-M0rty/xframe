const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Department = require('../models/Department');
const Workshop = require('../models/Workshop');
const Employee = require('../models/Employee');
const { computeEffective } = require('../services/permissionService');
const { bindRequest, tenantContext, PLATFORM } = require('../services/tenantScope');
const { companyIdsForTenant, accountAccessProblem } = require('../services/tenantService');

/**
 * ============================================================
 * AUTH MIDDLEWARE
 * ============================================================
 * The token only proves WHO is calling (its `id`). Everything that
 * decides WHAT they may do — role, department, hrRole, linked
 * employee, account status — is read fresh from the database on
 * every request.
 *
 * Why not just trust the token's own claims (as this used to):
 *
 * 1. Stale permissions. A login token lives 7 days. If an admin
 *    changed someone's department to "hr", or linked them to an HR
 *    employee (which re-derives department/hrRole — see
 *    services/employeeAccountService.js), the frontend showed HR
 *    menus immediately (it reloads the user from /users/me) while
 *    the backend kept treating them as non-HR until they logged out
 *    and back in. Visible symptom: an HR account opening Employees
 *    and seeing an EMPTY company dropdown, because GET /companies
 *    fell back to "only companies you own".
 *
 * 2. hrRole was never in the token at all, so on the backend every
 *    HR user's tier was undefined — which permissions.js treats as
 *    full Responsable-RH authority for backward compatibility. The
 *    HR tier hierarchy (assistant/officer/manager/director) wasn't
 *    actually being enforced server-side.
 *
 * 3. Suspended/deactivated accounts kept full access until their
 *    token expired.
 *
 * Cost: one indexed findById per request, projecting only the few
 * fields below and using .lean() — negligible next to the route's
 * own queries.
 *
 * req.user keeps the exact shape routes already rely on (id as a
 * string, plus email/role/department/employee), with hrRole added.
 * ============================================================
 */

const BLOCKED_STATUSES = new Set(['inactive', 'suspended']);

const auth = async (req, res, next) => {
  // Already authenticated earlier in this request (router-level auth +
  // a route that repeats it): nothing to redo, we're inside its context.
  if (req._authenticated && req.user) return next();
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({ message: 'No token provided' });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (error) {
      return res.status(401).json({ message: 'Invalid token', error: error.message });
    }

    // The short-lived 2FA challenge token (see controllers/
    // authController.js) is signed with the same secret but only
    // proves the PASSWORD step — it must never work as a session
    // token, or anyone with a password could skip the 2FA code by
    // calling the API directly with it.
    if (decoded.purpose) {
      return res.status(401).json({ message: 'Invalid token' });
    }

    const user = await User.findById(decoded.id)
      .select('email role department hrRole employee status tenant showFinancials permissionsMode permissions')
      .lean();

    if (!user) {
      return res.status(401).json({ message: 'Account no longer exists' });
    }

    if (BLOCKED_STATUSES.has(user.status)) {
      return res.status(401).json({ message: 'This account has been deactivated' });
    }

    // Client (tenant) checks — a suspended client, or an account not
    // attached to any client, is cut off here even mid-session.
    // 401 (not 403): the session itself is no longer valid, so the
    // app logs the person out — same as a deactivated account.
    const clientProblem = await accountAccessProblem(user);
    if (clientProblem) {
      return res.status(401).json({ message: clientProblem.message });
    }

    // The isolation context every query of this request runs under
    // (services/tenantScope.js). A platform_admin gets the platform
    // context: no client business data unless a platform route opts
    // in explicitly.
    const isPlatform = user.role === 'platform_admin';
    const ctx = isPlatform
      ? PLATFORM
      : tenantContext({
          tenantId: user.tenant,
          companyIds: await companyIdsForTenant(user.tenant),
          userId: String(user._id),
        });

    return bindRequest(req, ctx, async () => {
      try {
        // Departments this person runs (Department.manager) — powers the
        // department-wide approval rights in permissions/permissions.js
        // and the "My department" page. Only looked up for accounts
        // linked to an employee, since only employees can manage one.
        const managedRows = user.employee && !isPlatform
          ? await Department.find({ manager: user.employee }).select('_id permissionKey').lean()
          : [];
        const managedDepartments = managedRows.map((d) => String(d._id));
        // People reporting to this login's employee → they can hand out
        // (their own) permissions to their team.
        const hasReports = user.employee && !isPlatform
          ? !!(await Employee.exists({ manager: user.employee }))
          : false;

        // Workshops (ateliers) this person runs or works in — gives the
        // workshop screens to people outside the production department.
        let workshops = [];
        let managedWorkshops = [];
        if (user.employee && !isPlatform) {
          const rows = await Workshop.find({ $or: [{ manager: user.employee }, { members: user.employee }] }).select('_id manager').lean();
          workshops = rows.map((w) => String(w._id));
          managedWorkshops = rows.filter((w) => String(w.manager) === String(user.employee)).map((w) => String(w._id));
        }

        req.user = {
          id: String(user._id),
          email: user.email,
          role: user.role,
          department: user.department,
          hrRole: user.hrRole,
          showFinancials: user.showFinancials === true,
          employee: user.employee ? String(user.employee) : null,
          tenant: user.tenant ? String(user.tenant) : null,
          managedDepartments,
          workshops,
          managedWorkshops,
          permissionsMode: user.permissionsMode || 'role',
        };
        // Every permission check reads this set (services/permissionService.js).
        req.user.perms = isPlatform ? new Set() : computeEffective(user, {
          workshops,
          managedWorkshops,
          managedDepartmentKeys: managedRows.map((d) => d.permissionKey).filter(Boolean),
          managedDepartmentCount: managedRows.length,
          hasReports,
        });

        req._authenticated = true;
        next();
      } catch (error) {
        console.error('Auth middleware error:', error);
        res.status(500).json({ message: 'Authentication check failed' });
      }
    });
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({ message: 'Authentication check failed' });
  }
};

module.exports = auth;
