import { createContext, useState, useEffect, useMemo } from 'react';
import api from '../services/api';
import { getCurrentUser } from '../services/userService';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  // True until we've resolved whether the stored token maps to a
  // real user. Prevents a flash of "logged out" UI (and hides
  // role-gated buttons like Edit/Delete) while that check is in flight.
  const [loading, setLoading] = useState(!!localStorage.getItem('token'));

  useEffect(() => {
    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }
  }, [token]);

  // On first load (and on every refresh) we only have the raw token
  // in localStorage — `user` starts out null. Without this, every
  // role check in the UI (canManageUser, canDeleteUser, etc.) sees a
  // null actor and hides Edit/Delete buttons even for an owner/admin.
  // Fetch the real profile from /users/me to repopulate `user`.
  useEffect(() => {
    const restoreSession = async () => {
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        const currentUser = await getCurrentUser();
        setUser(currentUser);
      } catch (error) {
        // Token is invalid/expired - clear it out.
        setToken(null);
        setUser(null);
        localStorage.removeItem('token');
        delete api.defaults.headers.common['Authorization'];
      } finally {
        setLoading(false);
      }
    };

    restoreSession();
    // Only run this on mount / when the token itself changes (e.g. login/logout),
    // not on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const login = async (email, password) => {
    setLoading(true);
    try {
      const response = await api.post('/auth/login', { email, password });

      // An account with 2FA enabled doesn't get a real session here
      // — the backend hands back a short-lived challengeToken
      // instead (see routes/twoFactor.js), which only proves the
      // password was correct. LoginPage.jsx uses this to show a
      // second "enter your code" step, then calls
      // verifyTwoFactorLogin below to actually finish logging in.
      if (response.data.data.requires2FA) {
        return { success: false, requires2FA: true, challengeToken: response.data.data.challengeToken };
      }

      const { token: newToken, user: userData } = response.data.data;

      setToken(newToken);
      localStorage.setItem('token', newToken);
      api.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;
      // The full profile (managed departments, workshops…) comes from /users/me.
      let fullUser = userData;
      try { fullUser = { ...userData, ...(await getCurrentUser()) }; } catch { /* keep the login payload */ }
      setUser(fullUser);

      return { success: true, user: fullUser };
    } catch (error) {
      return { success: false, error: error.response?.data?.message };
    } finally {
      setLoading(false);
    }
  };

  // Completes a login that was interrupted by a 2FA challenge.
  // `code` is either a 6-digit authenticator code or one of the
  // account's backup codes — the backend tells them apart itself.
  const verifyTwoFactorLogin = async (challengeToken, code) => {
    setLoading(true);
    try {
      const response = await api.post('/2fa/verify-login', { challengeToken, token: code });
      const { token: newToken, user: userData, usedBackupCode } = response.data.data;

      setToken(newToken);
      setUser(userData);
      localStorage.setItem('token', newToken);
      api.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;

      return { success: true, usedBackupCode, user: userData };
    } catch (error) {
      return { success: false, error: error.response?.data?.message };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    delete api.defaults.headers.common['Authorization'];
  };

  // Memoized so consumers only re-render when something in here
  // actually changed — previously this object literal was rebuilt
  // on every AuthProvider render, which (combined with the
  // sidebar's section-expand logic depending on `user`) could
  // cause a manually-expanded sidebar section to keep getting
  // silently re-collapsed back to whichever section matches the
  // current route.
  const value = useMemo(
    () => ({ user, token, login, verifyTwoFactorLogin, logout, loading }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [user, token, loading]
  );

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};