const Notification = require("../models/Notification");
const User = require("../models/User");

/**
 * Finds the User accounts that should be notified about HR events
 * for a given company: platform admins, the company's owner, and
 * any "hr" department user. (Mirrors canAccessHRForCompany in
 * permissions/permissions.js — these are exactly the people that
 * function says can manage this company's HR data.)
 */
async function getHRRecipientIds(company) {
  const users = await User.find({
    $or: [
      { role: "admin" },
      { _id: company?.owner },
      { department: "hr" },
    ],
  }).select("_id");

  return users.map((u) => u._id.toString());
}

/**
 * Creates an in-app notification for one user. This is the ONE
 * place to wire in real email/SMS later (e.g. call a mailer here
 * after the Notification.create) — every call site in the app
 * routes through this function already, so nothing else needs to
 * change when that's added.
 */
async function notify(userId, { type, title, message, link }) {
  if (!userId) return null;

  try {
    return await Notification.create({
      user: userId,
      type,
      title,
      message,
      link,
    });
  } catch (error) {
    console.error("Notification create failed:", error);
    return null;
  }
}

/**
 * Notify every user in `userIds` with the same notification.
 */
async function notifyMany(userIds = [], payload) {
  return Promise.all(
    [...new Set(userIds.filter(Boolean).map(String))].map((id) =>
      notify(id, payload)
    )
  );
}

module.exports = { notify, notifyMany, getHRRecipientIds };
