// Must load before the schema is compiled — registers the client-isolation plugin.
require("../services/tenantScope");
const mongoose = require("mongoose");

/**
 * PROFILE SERIES (série / gamme de profilés) — e.g. "Coulissant 67",
 * "Ouvrant RPT 50", "Façade VEC 52". Each series has its own VARIABLES
 * (clearances, overlaps, deductions) that every chassis model of the
 * series uses in its formulas, so one change here updates all of them.
 */
const variableSchema = new mongoose.Schema({
  key: { type: String, required: true, trim: true },
  label: { type: String, trim: true, maxlength: 150 },
  value: { type: Number, required: true, default: 0 },
}, { _id: false });

/**
 * PROFILE TYPES of the series ("Ouvrant", "Dormant", "Traverse"…): the
 * geometry every profile of that type shares in this series. Articles
 * attached to a type (Product.profileSeries + profileType) receive these
 * values — services/profileTypes.js copies them onto the articles, so
 * the BOM, the débit and the planning keep reading the article as
 * before. A value set on the article itself (Product.geometryOwn) wins.
 */
const num = { type: Number, default: null, min: 0 };
const profileTypeSchema = new mongoose.Schema({
  key: { type: String, required: true, trim: true, maxlength: 60 },
  label: { type: String, required: true, trim: true, maxlength: 80 },
  // extra words that identify this type in article names ("vantail" for "Ouvrant")
  keywords: [{ type: String, trim: true, maxlength: 40 }],
  ch: num, // épaisseur de chambre
  ae: num, // ailette externe
  ai: num, // ailette interne
  lp: num, // largeur du profilé
  barLength: num,
  weightPerMeter: num,
  perimeter: num, // développé laquable
}, { _id: false });

const profileSeriesSchema = new mongoose.Schema(
  {
    company: { type: mongoose.Schema.Types.ObjectId, ref: "Company", required: true, index: true },
    name: { type: String, required: true, trim: true, maxlength: 100 },
    supplier: { type: String, trim: true, maxlength: 100, default: "" },
    families: [{ type: String, trim: true }],
    description: { type: String, trim: true, maxlength: 1000 },
    variables: [variableSchema],
    profileTypes: [profileTypeSchema],
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);
profileSeriesSchema.index({ company: 1, name: 1 }, { unique: true });

module.exports = mongoose.model("ProfileSeries", profileSeriesSchema);
