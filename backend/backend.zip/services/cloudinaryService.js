const cloudinary = require("../config/cloudinary");
const streamifier = require("streamifier");

const uploadImage = (buffer, folder) => {
  return new Promise((resolve, reject) => {
    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder,
        resource_type: "image",
        transformation: [
          {
            width: 1000,
            height: 1000,
            crop: "limit",
            quality: "auto",
            fetch_format: "auto",
          },
        ],
      },
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      }
    );

    streamifier
      .createReadStream(buffer)
      .pipe(uploadStream);
  });
};

/**
 * Generic file upload — unlike uploadImage above, this does NOT
 * force resource_type "image" or apply an image transformation, so
 * it also works for PDFs (very common for employee documents: CIN
 * scans, signed contracts, diplomas). Cloudinary's "auto" resource
 * type picks image/video/raw automatically based on the file.
 */
const uploadFile = (buffer, folder, originalName) => {
  return new Promise((resolve, reject) => {
    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder,
        resource_type: "auto",
        use_filename: true,
        filename_override: originalName,
      },
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      }
    );

    streamifier
      .createReadStream(buffer)
      .pipe(uploadStream);
  });
};

const deleteImage = async (publicId) => {
  if (!publicId) return null;

  return cloudinary.uploader.destroy(publicId);
};

/**
 * Deletes a file uploaded via uploadFile — needs resource_type
 * "auto" resolution too, since a PDF is stored as "raw" while an
 * image is stored as "image"; passing the wrong resource_type to
 * destroy() silently fails to delete it. Cloudinary doesn't expose
 * "auto" for destroy, so we try both.
 */
const deleteFile = async (publicId) => {
  if (!publicId) return null;

  try {
    return await cloudinary.uploader.destroy(publicId, { resource_type: "raw" });
  } catch (error) {
    return cloudinary.uploader.destroy(publicId, { resource_type: "image" });
  }
};

module.exports = {
  uploadImage,
  uploadFile,
  deleteImage,
  deleteFile,
};